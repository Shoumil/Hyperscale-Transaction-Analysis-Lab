console.log('Loading the octankTelematicsTripReader function');
const AWS = require('aws-sdk');
const AWSXRayCore = require('aws-xray-sdk-core');
const AWSXRay= require('aws-xray-sdk');
const { v4: uuidv4 } = require('uuid');

exports.handler = async(event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    AWSXRayCore.captureAWS(AWS);
    const segment = AWSXRay.getSegment();
    let subsegment = segment.addNewSubsegment("octankTelematicsTripReader");

    let result = {};
    if (isEmpty(event.tripId)) {
        result.statusCode = '400';
        result.body = "Invalid Input";
        callback(null, result);
        return;
    }

    subsegment.addAnnotation("tripId", event.tripId.toString());
    
    try {
        let docClient = new AWS.DynamoDB.DocumentClient();
        let table = "octankTelematicsTrips";

        let params = {
            TableName: table,
            KeyConditionExpression: "tripId = :tripId",
            ExpressionAttributeValues: {
                ":tripId": event.tripId
            }
        };

        let data = await docClient.query(params).promise();
        result = formatTrip(data);
        subsegment.addAnnotation("userId", result.userId.toString());
    }
    catch (err) {
        console.log("Error:" + JSON.stringify(err));
        subsegment.addError(err);
    }
    finally {
        subsegment.close();
    }
    console.log("Result: " + JSON.stringify(result));
    return result;
}

function isEmpty(token) {
    if (token == null ||
        token == undefined ||
        token.length == 0) {
        return true;
    }
    else {
        return false;
    }
}

function formatTrip(data) {
    if (isEmpty(data) || isEmpty(data.Items)) {
        return null;
    }
    let result = {
        "tripId": data.Items[0].tripId,
        "userId": data.Items[0].userId,
        "tripEvents": []
    };
    for (const record of data.Items) {
        result.tripEvents.push({
            "eventId": record.eventId,
            "eventType": record.eventType,
            "coordinates": record.coordinates,
            "timestamp": record.timestamp
        });
    }
    return result;
}
