console.log('Loading the Calc function');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

exports.handler = function(event, context, callback) {
    console.log('Received event:', JSON.stringify(event, null, 2));
   
    let res = {};
    res.statusCode; 
    if (isEmpty(event.tripEvent) || isEmpty(event.tripId)) {
        res.statusCode = '400';
        res.body = "Invalid Input";
        callback(null, res);
        return;
    }

     const params = {
        Data: JSON.stringify(event),
        PartitionKey: event.tripId,
        StreamName: "octankTelematicsEvents"
    };
    
    try{
        switch(event.tripEvent)
        {
            case "Started":
            case "Ended":
                let kinesis = new AWS.Kinesis();
                 kinesis.putRecord(params, function(err, data) {
                    if (err){
                        console.log(err, err.stack);
                    }else
                    {
                        console.log('Record added:',data);
                    }
                });
                res.statusCode= '200'; 
                res.body = "status: Queued";
                break;
            default:
                res.statusCode = '500';
                res.body ="Invalid Trip Event Type";
                break;
        }
    } catch (err) {
        res.statusCode = '500';
        res.body = "Internal Error";
    } finally {
        //res.body = JSON.stringify(res.body);
    }
    callback(null, res);
};

function isEmpty(token) {
    if (token == null ||
        token == undefined ||
        token.length == 0) {
        return true;
    }
    else {
        return false;
    }
}