console.log('Loading the octankTelematicsTripDBWriter function');
const AWS = require('aws-sdk');
const AWSXRayCore = require('aws-xray-sdk-core');
const AWSXRay = require('aws-xray-sdk');
const { v4: uuidv4 } = require('uuid');

exports.handler = async(event, context) => {
    AWSXRayCore.captureAWS(AWS);
    const segment = AWSXRay.getSegment();
    let subsegment = segment.addNewSubsegment("octankTelematicsTripDBWriter");
    
    let docClient = new AWS.DynamoDB.DocumentClient();
    let params = {};
    let data = null;
    let records = [];
    for (const record of event.Records) {

        const payload = Buffer.from(record.kinesis.data, 'base64').toString('utf8');
        data = JSON.parse(payload);
        let subseg = segment.addNewSubsegment("Trip Id : " + data.tripId.toString());

        subseg.addAnnotation("tripId", data.tripId.toString());
        subseg.addAnnotation("userId", data.userId.toString());
        console.log("records length prior iteration: " + records.length);
        for (const tripEvent of data.tripEvents) {
            records.push({
                PutRequest: {
                    Item: {
                        "eventId": tripEvent.eventId,
                        "tripId": data.tripId,
                        "userId": data.userId,
                        "eventType": tripEvent.eventType,
                        "coordinates": {
                            "latitude": tripEvent.coordinates.latitude,
                            "longitude": tripEvent.coordinates.longitude
                        },
                        "timestamp": tripEvent.timestamp
                    }
                }
            });
        }
        params = {
            RequestItems: {
                "octankTelematicsTrips": records
            }
        }
        try {
            console.log("Adding a new trip..." + JSON.stringify(data));
            console.log("Adding a new trip params..." + JSON.stringify(params));
            console.log("Number of events to be inserted: " + records.length);
            let body = await docClient.batchWrite(params).promise();
            console.log(JSON.stringify(body));
        }
        catch (err) {
            console.log("error: " + JSON.stringify(err));
            subseg.addError(err);
        }
        finally {
            subseg.close();
            records = [];
        }
    }
    subsegment.close();
    return `Successfully processed ${event.Records.length} records.`;
}
