console.log('Loading the octankTelematicsTripEventWriter function');
const AWS = require('aws-sdk');
const AWSXRayCore = require('aws-xray-sdk-core');
const AWSXRay= require('aws-xray-sdk');
const { v4: uuidv4 } = require('uuid');

exports.handler = function(event, context, callback) {
    console.log('Received event:', JSON.stringify(event, null, 2));
    AWSXRayCore.captureAWS(AWS);
    const segment= AWSXRay.getSegment();
    const subsegment = segment.addNewSubsegment("octankTelematicsTripEventWriter");
    let res = {};
    res.statusCode; 
    if (isEmpty(event.userId) || isEmpty(event.tripId) || isEmpty(event.tripEvents)) {
        res.statusCode = '400';
        res.body = "Invalid Input";
        callback(null, res);
        return;
    }

    subsegment.addAnnotation("tripId", event.tripId.toString());
    subsegment.addAnnotation("userId", event.userId.toString());
    
    const params = {
        Data: JSON.stringify(event),
        PartitionKey: event.tripId,
        StreamName: "octankTelematicsTripEvents"
    };
    
    let message = {};
    try{
        let kinesis = new AWS.Kinesis();
        kinesis.putRecord(params, function(err, data) {
            if (err){
                console.log(err, err.stack);
            }else
            {
                console.log('Record added:',data);
            }
        });
        res.statusCode= '200'; 
        res.body = "status: Queued";
    } catch (err) {
        res.statusCode = '500';
        res.body = "Internal Error";
        subsegment.addError(err);
    } finally {
        subsegment.close();
    }
    callback(null, res);
};

function isEmpty(token) {
    if (token == null ||
        token == undefined ||
        token.length == 0) {
        return true;
    }
    else {
        return false;
    }
}
